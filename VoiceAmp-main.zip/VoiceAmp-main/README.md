# VoiceAmp
Voice amplifier for Gorilla Tag

*Needs Computer Interface (available on MMM https://github.com/DeadlyKitten/MonkeModManager/releases)*

To use this go to the computer and in the "Voice Amp" menu.  
There you can set the amplifier and apply via enter.  
*Updates automatically even when in room*
