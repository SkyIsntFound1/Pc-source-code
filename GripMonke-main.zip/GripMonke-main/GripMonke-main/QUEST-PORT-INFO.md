**NEW AS OF SEPTEMBER 27th, 2021:**
Quest Gorilla Tag modding has been put on hold, potentially killed forever. RedBrumbler's MonkeCodegen was taken down and is no longer avaliable due to people working around private lobby checks and making mods not check for them.

Modding will not come back soon, and none of us are sure if it will come back **ever.**
**Plans for GripMonke Quest have been put on hold as well, and I am NOT going to start development on it until or if the modding scene for Quest comes back.**
Sorry for getting your hopes up, but GripMonke may never come to Quest. As of now, please use a PCVR streaming application such as Virtual Desktop or ALVR in the meantime.

____________________________________________________________________________________________________________________________________________________________________

Yes, I am interested in a **future** quest port. I'm going to wait until all of the stuff is updated for Quest, maybe a few weeks after. I want some practice with C++ and C# syntax first.

Note that this doesn't mean ***will***, I'm thinking about it.
