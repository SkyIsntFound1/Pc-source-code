﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilla
{
    public class ForcePrivateLobbyAttribute : Attribute
    {
    }
}
