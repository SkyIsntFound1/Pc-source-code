# What is this mod?
This is a library for a future plugins/mods.

## Manual Installation
Be sure that you are already installed BepInEx (using MonkeModManager for example). You need x64 version. [Take it there.](https://github.com/BepInEx/BepInEx/releases)

If your BepInEx copy installed then copy-paste BananaHook.dll to your Gorilla Tag/BepInEx/plugins folder somewhere (Gorilla Tag/BepInEx/BananaHook/BananaHook.dll for example).
