import shutil

shutil.make_archive("ComputerInterface", "zip", "ReleaseZip")