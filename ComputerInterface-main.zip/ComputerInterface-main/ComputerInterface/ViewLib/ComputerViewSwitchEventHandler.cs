﻿namespace ComputerInterface.ViewLib
{
    public delegate void ComputerViewSwitchEventHandler(ComputerViewSwitchEventArgs args);
}