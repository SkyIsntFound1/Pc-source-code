﻿namespace ComputerInterface.ViewLib
{
    public delegate void ComputerViewChangeBackgroundEventHandler(ComputerViewChangeBackgroundEventArgs args);
}