﻿namespace ComputerInterface
{
    public static class PluginInfo
    {
        public const string Name = "Computer Interface";
        public const string Id = "tonimacaroni.computerinterface";
        public const string Version = "1.4.6";
    }
}