﻿namespace ComputerInterface
{
    public static class Helpers
    {
    }
}