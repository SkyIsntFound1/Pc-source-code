# WhyGravity
Zero Gravity mod for Gorilla Tag PCVR

This is my first mod, yes it was made using fchb1239#5358's Tutorial (Massive shoutout to that guy, he got me into making mods)

Gravity is overrated, get rid of it by using this mod

Hold the "grip button" (On the side of the controller) of the right controller and you'll lose gravity. Release to restore normal gravity. 
All momentum will be held when losing gravity

Mod is automatically activated. You can turn it off by going into the computer's "Mod Status" Window and disabling it.

Mod Shouldn't be used in any Public lobbies or anything that isn't private/With friends.

I am not responsible for anyone getting banned and/or in trouble using this mod.

Last updated 21-9-2021
Patch Notes:
-Removed PBBV
(^ This is a bad joke)
