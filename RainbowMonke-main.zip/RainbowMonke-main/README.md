<h1>Rainbow Monke Mod</h1>
<p>This is a mod for gorilla tag which can be run using <a href="https://github.com/DeadlyKitten/MonkeModManager/releases/tag/v1.2.0">Monke Mod Manager</a></p>
<h1>Instructions</h1>
<ol>
<li>Download <a href="https://github.com/DeadlyKitten/MonkeModManager/releases/tag/v1.2.0">Monke Mod Manager</a> and place it in your local files. Run <code>MonkeModManager.exe</code>, navigate and select <code>Gorilla Tag.exe</code> in the file dialog and click <code>Install</code></li>
<li>Go to <code>BepInEx\Plguins</code> in your Gorilla Tag folder and place the <code>RainbowMonke.dll</code> in there</li>
<li>Run Monke Tag like usual and become Monke</li>
</ol>
<h2>Notes</h2>
<ul>
<li>The mod only works in Private Lobbies, and other players can see your rainbow skin</li>
<li>If you have the cosmetics mod installed, you won't be able to see your own rainbow skin</li>
</ul>
<h2>Other stuff</h2>
<ul>
<li>This mod also has settings such as <code>Cycle Speed</code>, <code>Random Colour</code> and <code>Brightness</code></li>
<li>These settings can be found in the config file at <code>BepInEx\config\RainbowMonke.cfg</code></li>
  <li>The mod can also be <code>Disabled/Enabled</code> in the config</li>
</ul>
