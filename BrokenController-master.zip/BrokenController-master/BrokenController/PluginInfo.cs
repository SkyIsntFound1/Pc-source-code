﻿
namespace BrokenController
{
    class PluginInfo
    {
        public const string GUID = "com.author.gorillatag.brokencontroller";
        public const string Name = "BrokenController";
        public const string Version = "1.0.1";
    }
}
