A very fast flight mod for PC gorilla tag.


<h3>Instructions</h3><br>
-Download, make a folder in the plugins folder and drag and drop the zip file into it and extract it make sure there is one folder, make sure you are using BepInEx.<br>
-Hold the B button down to fly<br>
-Hit the A button to stop all velocity<br>
-hold the grip button to activate the dot.<br>
-hold the trigger + grip to move towards the dot(looks better in-game.)<br>
-Hold the right grip button and the B button to enter super sonic mode.<br>
-Hold the right grip, right trigger and the B button to activate god mode and fly like god.<br>
-just edit the config file in your notepad/text editor MAKE SURE THERE ARE NO SPACES IN THE CONFIG.<br>
-to activate hand direction set the 10 line to "true" with no space after(Deactivate by setting it to "false").<br>
-to activate dot movement set the value in the config to "true", no space.<br>
-if you set the config speed on any of the values above 8000 then the mod will turn off.<br>
<br>
IMPORTANT make sure that the config AND the dll file are both in a folder name FlyFast MAKE SURE the F are both capital.<br>
<br>
also these controls are for the oculus quest so if you have a different headset good luck, but it still will work.<br>
<br>
Does not work in public lobby's and make sure to download it though the releases<br>
