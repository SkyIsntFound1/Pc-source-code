# What is this mod?
NoAmbient allows you to remove ambient sound (forest birds, canyon wind, cave water)

## Manual Installation
Be sure that you are already installed BepInEx (using MonkeModManager for example). You need x64 version. [Take it there.](https://github.com/BepInEx/BepInEx/releases)

Unpack downloaded NoAmbient.zip to GorillaTag's root folder (near the .exe file)

## Optional
For using it through the ComputerInterface, you should have ComputerInterface. And Bepinject & Zenject.

## Config

You can found a config at this path: `Gorilla Tag/BepInEx/config/NoAmbient.cfg`
Alternatively you can use ComputerInterface.