# Upside Down Monke

**Be upside down!**

- You are upside down.
- You can join other upside downians.
- And you're upside down!

## [Direct Download](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

# Installing
Place the UpsideDownMonke.dll into your BepInEx plugins folder. If you do not have BepInEx, or don't know how to install it, take a look at this fancy website for fancy people.
[Gorilla Tag Modding Guide](https://gorillatagmodding.burrito.software/)

![Insert picture of sexy monke here.](https://cdn.shopify.com/s/files/1/0251/3122/1073/products/265-Uno-Reverse-Card_1500x.png?v=1617718112)

Todo,
- Actually flip the player model.
- Make it so you can join other people who are upside down.
- Make the computer easier to use?