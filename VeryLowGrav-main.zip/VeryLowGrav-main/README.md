Hello! This is my first mod so dont hate pls

This mod needs to be activated from Mod Status on ComputerInterface
https://github.com/ToniMacaroni/ComputerInterface/releases

Hold down the "B" Button on the right controller, Thats basically it!
