﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GorillaCosmetics.Data
{
    [System.Serializable]
    public class VRRigHatJSON
    {
        public string hat;
        public string material;
    }
}
