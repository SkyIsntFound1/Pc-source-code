﻿using System;
using System.Collections;
using UnityEngine;

namespace VmodMonkeMapLoader
{
    /// <summary>
    /// Shared monobehaviour which starts coroutines from non-monobehaviour classes
    /// </summary>
    public class SharedCoroutineStarter : MonoBehaviour
    {
    }
}