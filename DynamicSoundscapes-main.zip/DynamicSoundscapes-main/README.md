# Dynamic Soundscapes

**Adds dynamic sound to the game.**

- The forest now has birds and the occasional sound of wind blowing though trees.
- The caves are now echoey and have cave sounding sounds.
- The cosmetic room has some nice music.
- The canyons now have wind sounds.
- You can hear wind when falling.
- The gorilla OS computer keyboard now plays sounds when typing.
- And more to come!

## [Direct Download](https://github.com/auralius-dev/SmoothMonke/releases/download/1.0.0/SmoothMonke.dll)

# Installing
Smoothly place the DynamicSoundscapes.dll into your BepInEx plugins folder. If you do not have BepInEx, or don't know how to install it, take a look at this fancy website for fancy people.
[Gorilla Tag Modding Guide](https://gorillatagmodding.burrito.software/)

![Insert picture of sexy monke here.](https://raw.githubusercontent.com/auralius-dev/SmoothMonke/main/img/smooth_monke.jpg)

Todo,
- Rewrite the codebase.
- Put ReverbPresetArrays somewhere else
- Rewrite all the actual audio crap.
- Remove unnecessary variables.
- When custom map loader comes out or I get access to it (plz gimmie) add ability for custom maps to add custom audio triggers and sounds.
- Change reverb of canyon 'houses'.
- Change cave ambience to something a little more light.
- Remove wind from forest ambience and add it to the trees.
- Add step sounds per material.
- Add configuration for reverb. (Oh noes..)