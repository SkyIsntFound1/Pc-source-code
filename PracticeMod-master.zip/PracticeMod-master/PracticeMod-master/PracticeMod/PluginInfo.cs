﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PracticeMod
{
	public static class PluginInfo
	{
		public const string GUID = "io.github.graicc.gorillatag.practicemod";
		public const string Name = "Practice Mod";
		public const string Version = "1.1.0";
	}
}
